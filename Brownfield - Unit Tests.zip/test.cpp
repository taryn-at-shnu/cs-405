// Taryn Brownfield - Module 4 Milestone

// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// DONE: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());   // TB - same as above

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);   // TB - same as above

    add_entries(1);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());  // TB - Assert that the collection is no longer empty
    
    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 1);   // TB - Assert that the collection now has a size of 1
}

// DONE: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);

    // Verify that the size of the collection is now 5
    ASSERT_EQ(collection->size(), 5);
}

// DONE: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaximumSizeIsGreaterThanOrEqualTo10OrFewer)
{
    // Maximum size >= 0
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // verify that max size >= collection->size()
    ASSERT_GE(collection->max_size(), collection->size());

    // Maximum size >= 1
    add_entries(1);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());  // No need to check this again beyond this point.
    // collection should contain 1 entry
    ASSERT_EQ(collection->size(), 1);
    // verify that max size >= collection->size()
    ASSERT_GE(collection->max_size(), collection->size());

    // Maximum size >= 5
    add_entries(4); // collection already has 1 entry, so add 4 more
    // collection should contain 5 entries
    ASSERT_EQ(collection->size(), 5);
    // verify that max size >= collection->size()
    ASSERT_GE(collection->max_size(), collection->size());

    // Maximum size >= 10
    add_entries(5); // collection already has 5 entries, so add 5 more
    // collection should contain 10 entries
    ASSERT_EQ(collection->size(), 10);
    // verify that max size >= collection->size()
    ASSERT_GE(collection->max_size(), collection->size());
}

// DONE: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualTo10OrFewer)
{
    // Capacity >= 0
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // verify that capacity >= collection->size()
    ASSERT_GE(collection->capacity(), collection->size());

    // Capacity >= 1
    add_entries(1);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());  // No need to check this again beyond this point.
    // collection should contain 1 entry
    ASSERT_EQ(collection->size(), 1);
    // verify that capacity >= collection->size()
    ASSERT_GE(collection->capacity(), collection->size());

    // Capacity >= 5
    add_entries(4); // collection already has 1 entry, so add 4 more
    // collection should contain 5 entries
    ASSERT_EQ(collection->size(), 5);
    // verify that capactiy >= collection->size()
    ASSERT_GE(collection->capacity(), collection->size());

    // Capacity >= 10
    add_entries(5); // collection already has 5 entries, so add 5 more
    // collection should contain 10 entries
    ASSERT_EQ(collection->size(), 10);
    // verify that capacity >= collection->size()
    ASSERT_GE(collection->capacity(), collection->size());
}

// DONE: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, CanResizeToIncreasesCollection)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // add 3 entries by resizing
    collection->resize(3);
    // verify collection is no longer empty
    ASSERT_FALSE(collection->empty());
    // verify that collection has size 3
    ASSERT_EQ(collection->size(), 3);
}

// DONE: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, CanResizeToDecreaseCollection)
{
    // add 3 entries
    add_entries(3);
    // verify that collection has size 3
    ASSERT_EQ(collection->size(), 3);
    // remove 2 entries by resizing
    collection->resize(1);
    // verify collection now has size 1
    ASSERT_EQ(collection->size(), 1);
}

// DONE: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, CanResizeToZero)
{
    // add 3 entries
    add_entries(3);
    // verify collection is not empty
    ASSERT_FALSE(collection->empty());
    // verify that collection has size 3
    ASSERT_EQ(collection->size(), 3);
    // remove all entries by resizing
    collection->resize(0);
    // verify collection now has size 0
    ASSERT_EQ(collection->size(), 0);
    // verify collection is now empty
    ASSERT_TRUE(collection->empty());
}

// DONE: Create a test to verify clear erases the collection
TEST_F(CollectionTest, IsEmptyAfterClearingCollection)
{
    // add 3 entries
    add_entries(3);
    // verify collection is not empty
    ASSERT_FALSE(collection->empty());
    // clear collection
    collection->clear();
    // verify collection is now empty
    ASSERT_TRUE(collection->empty());
}

// DONE: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, IsEmptyAfterErasingCollection)
{
    // add 3 entries
    add_entries(3);
    // verify collection is not empty
    ASSERT_FALSE(collection->empty());
    // clear collection
    collection->erase(collection->begin(), collection->end());
    // verify collection is now empty
    ASSERT_TRUE(collection->empty());
}

// DONE: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize)
{
    // add 3 entries
    add_entries(3);
    // verify that collection has size 3
    ASSERT_EQ(collection->size(), 3);
    // verify that collection has capacity 3
    ASSERT_EQ(collection->capacity(), 3);
    // reserve greater capactiy
    collection->reserve(10);
    // verify that collection size has not changed
    ASSERT_EQ(collection->size(), 3);
    // verify that capacity is now 10
    ASSERT_EQ(collection->capacity(), 10);
}

// DONE: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, CanThrowOutOfRangeException)
{
    // add 3 entries
    add_entries(3);
    // verify that collection has size 3
    ASSERT_EQ(collection->size(), 3);
    // verify that an exception is thrown when attempting to access beyond the current size
    ASSERT_THROW(collection->at(4), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
TEST_F(CollectionTest, CanPopLastElement)
{
    // add 3 entries
    add_entries(3);
    // verify that collection has size 3
    ASSERT_EQ(collection->size(), 3);
    // remove last element
    collection->pop_back();
    // verify that collection now has size 2
    ASSERT_EQ(collection->size(), 2);
}

TEST_F(CollectionTest, CanThrowErrorBeyondMaxSize)
{
    // verify that an error is thrown when attempting to reserve beyond the maximum size
    ASSERT_THROW(collection->reserve(collection->max_size()+1), std::length_error);
}